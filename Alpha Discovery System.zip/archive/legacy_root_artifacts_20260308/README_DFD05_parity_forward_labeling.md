# DFD05 parity + forward labeling

This package implements a Python parity simulator for:

`16. Divergence Feature Discovery System - LONG ONLY (Baseline + Toggles) [v6 FIXED + Session Gate]`

and produces forward-horizon labels (TP/SL first-touch + MFE/MAE).

## CLI

```bash
python -m dfd05.run --config configs/dfd05.yaml
```

## Pine16 Exact Workflow (Source-of-Truth)

Use the Pine16 exact namespace for strict truth-separation between:

- `EXACT_PINE_EXPORTED` (TradingView-exported artifacts)
- `VERIFIED_PYTHON_PARITY` (only after parity thresholds pass against Pine exports)
- `UNVERIFIED_PYTHON_APPROXIMATION` (fallback, never exact)

Commands:

```bash
python -m scripts.pine16_prepare_export_templates
python -m scripts.pine16_ingest_tv_exports --imports-dir tv_exports/
python -m scripts.pine16_reconcile_exports --config configs/pine16_exact_prod_screenshot.yaml
python -m scripts.pine16_verify_parity --config configs/pine16_exact_prod_screenshot.yaml
python -m scripts.pine16_exact_report --config configs/pine16_exact_prod_screenshot.yaml --truth-mode exact_pine_exported
python -m scripts.pine16_exact_report --config configs/pine16_exact_prod_screenshot.yaml --truth-mode verified_python_parity
python -m scripts.pine16_plus1r_plus3r_report --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode exact_pine_exported
python -m scripts.pine16_plus1r_plus3r_report --config configs/pine16_exact_prod_london_only.yaml --truth-mode exact_pine_exported
python -m scripts.pine16_plus1r_plus3r_report --config configs/pine16_exact_prod_newyork_only.yaml --truth-mode exact_pine_exported
python -m scripts.pine16_plus1r_plus3r_report --config configs/pine16_exact_prod_london_or_newyork.yaml --truth-mode exact_pine_exported
python -m scripts.pine16_plus1r_plus3r_report --config configs/pine16_exact_prod_london_or_newyork.yaml --truth-mode verified_python_parity
python -m scripts.pine16_research_audit --audit-path outputs/audit_pine16_deep_research.md
python -m scripts.pine16_conditional_research --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity --min-n 20 --min-n-robust 30 --export-html
python -m scripts.pine16_feature_bucket_research --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity
python -m scripts.pine16_symbol_session_research --config configs/pine16_exact_prod_london_or_newyork.yaml --truth-mode verified_python_parity
python -m scripts.pine16_year_regime_research --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity
python -m scripts.pine16_path_quality_research --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity
python -m scripts.pine16_leaderboard_report --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity
python -m scripts.pine16_deployment_candidates --config configs/pine16_exact_prod_all_sessions.yaml --truth-mode verified_python_parity
```

Exact config pack files:

- `configs/pine16_exact_baseline.yaml`
- `configs/pine16_exact_prod_screenshot.yaml`
- `configs/pine16_exact_bos_only.yaml`
- `configs/pine16_exact_bos_plus_vol_entry.yaml`
- `configs/pine16_exact_prod_london_only.yaml`
- `configs/pine16_exact_prod_newyork_only.yaml`
- `configs/pine16_exact_prod_london_or_newyork.yaml`
- `configs/pine16_exact_prod_all_sessions.yaml`

## Inputs

- Preferred parquet:
  - `data/derived/dukascopy/parquet_m1|parquet_m15|parquet_m30|parquet_h1|parquet_h4/symbol=<SYM>/...*.parquet`
- Fallback parquet root:
  - `data/dukascopy/parquet_m1|parquet_m15|parquet_m30|parquet_h1|parquet_h4/symbol=<SYM>/...*.parquet`
- If canonical target timeframe bars are missing, loader resamples from the finest available source in `{m1, m15}` with OHLCV aggregation (`open=first, high=max, low=min, close=last, volume=sum`).
- Optional CSV per symbol in config (`data.csv_inputs`), coerced to:
  - `time, open, high, low, close, volume, symbol` (UTC)

## Outputs

- `data/derived/events_dfd05_<tf>_<runid>.parquet`
- `data/derived/forward_dfd05_<tf>_<runid>.parquet`
- Optional:
  - `data/derived/labeled_dfd05_<tf>_<runid>.parquet`
- `data/reports/dfd05_dashboard_<tf>_<runid>.csv`

### Event keys

Unique key columns:

- `symbol`
- `timeframe`
- `signal_id` (`{symbol}-{timeframe}-DFD05-{event_time_ms}`)
- `event_time_ms`

### Event core columns

- `entry_time_ms`, `entry_price`
- `pivot_time_ms`, `pivot_price`
- `mode` (`RAW` or `CONFIRM`)
- `trade_mode` (`BASELINE_ALL` or `GATED`)
- `toggles_json`

### Forward columns

Per horizon `<H>` (e.g., `24h`):

- `tp_first_<H>` (0/1)
- `sl_first_<H>` (0/1)
- `both_samebar_<H>` (0/1)
- `no_hit_<H>` (0/1)
- `is_truncated_<H>` (0/1)
- `mfe_<H>`
- `mae_<H>`
- optional resolved flags:
  - `tp_first_resolved_<H>`
  - `sl_first_resolved_<H>`

Also includes `sl_price` and `tp_price`.

## Forward Horizons

- Horizon set is config-driven (`forward.forward_horizons_hours`), default:
  - `[1, 2, 4, 6, 12, 24, 48, 72]`
- CLI override:
  - `python -m dfd05.run --config configs/dfd05.yaml --horizons 4,24,72`
- Timeframe conversion:
  - `bars = floor((H*60)/tf_minutes)`
  - if not divisible, a warning is logged and floor is used.
- Scan window:
  - from `entry_bar + 1` to `entry_bar + bars` (inclusive).
- Truncation:
  - if forward bars are insufficient, `is_truncated_<H>=1`,
    and `tp/sl/both/no_hit/mfe/mae` for that horizon are `NaN`.
- Same-bar touch:
  - `both_samebar_<H>=1`, while unresolved `tp_first/sl_first` remain `0`.
  - resolved columns apply tie-break (`sl` or `tp`) when `emit_resolved=true`.
- Validation in CLI:
  - for non-truncated rows, `tp + sl + both_samebar + no_hit == 1`.
- Dashboard/CLI report both:
  - `expR_total = rr*tp_resolved - sl_resolved` (no-hit treated as 0R)
  - `expR_hit_only` (conditioned on hit rows only)

## Timeframe + Horizon Evaluation

Use the multi-timeframe evaluator to run `dfd05.run` across timeframes and produce one master report set from time-only forward outcomes.

```bash
python scripts/dfd05_eval_timeframes.py \
  --config configs/dfd05_pine16_baseline.yaml \
  --parity pine16 \
  --timeframes m15,h1,h4 \
  --horizons 4,24,72 \
  --outdir data/reports/dfd05_timeframe_eval
```

Optional session comparison (`session_on` vs `session_off`):

```bash
python scripts/dfd05_eval_timeframes.py \
  --config configs/dfd05_pine16_baseline.yaml \
  --timeframes m15,h1,h4 \
  --horizons 4,24,72 \
  --compare_sessions \
  --outdir data/reports/dfd05_timeframe_eval
```

Generated artifacts:

- `data/reports/dfd05_timeframe_eval/overall_by_tf_h.csv`
- `data/reports/dfd05_timeframe_eval/per_symbol_year_by_tf_h.csv`
- `data/reports/dfd05_timeframe_eval/best_horizon_selection.csv`
- `data/reports/dfd05_timeframe_eval/summary.md`

Reported metrics (per timeframe+horizon, and per symbol+year):

- win-rate variants: `up`, `>=10/25/50/100bps`, `top_q80`, `mfeatr_top_q80`, `good`
- return distribution: `mean/median/p25/p50/p75`
- MFE/MAE means
- ATR-normalized means (`ret_atr`, `mfe_atr`, `mae_atr`)
- truncation rate

## Production BOS + Volume Config

Production preset:

- `configs/dfd05_pine16_prod_bos_vol.yaml`

Key differences vs Pine16 baseline:

- `strategy.mode=CONFIRM`
- `strategy.trade_mode=GATED`
- `strategy.use_bos_confirm=true`
- `strategy.bos_atr_buffer=0.10`
- `strategy.max_wait_bars=15`
- `strategy.one_trade_at_a_time=true`
- `strategy.cooldown_bars=0`
- `strategy.gate_vol_entry_at=signal` (supports `trigger` too)
- `toggles.enable_vol_ratio_entry_gate=true`
- `toggles.entry_vol_ratio_min=1.0`

Additional event fields for confirm flow:

- `setup_age_bars`
- `triggered_ok`

## Master Variant Evaluation

Use the master evaluator to run a matrix across variants, timeframes, sessions, and both metric levels:

- `level=signal` (all detected entries)
- `level=executed` (after one-trade-at-a-time horizon hold simulation)

```bash
python scripts/dfd05_eval_master.py \
  --configs baseline,prod \
  --parity pine16 \
  --timeframes m15,h1,h4 \
  --horizons 4,24,72 \
  --compare_sessions \
  --outdir data/reports/dfd05_master_eval
```

Optional timeframe param scaling:

```bash
python scripts/dfd05_eval_master.py \
  --configs baseline,prod \
  --timeframes m15,h1,h4 \
  --horizons 4,24,72 \
  --time_scale_params reference_tf=m15 \
  --outdir data/reports/dfd05_master_eval
```

Master artifacts:

- `data/reports/dfd05_master_eval/overall_by_variant_tf_h.csv`
- `data/reports/dfd05_master_eval/per_symbol_year_by_variant_tf_h.csv`
- `data/reports/dfd05_master_eval/best_horizon_selection.csv`
- `data/reports/dfd05_master_eval/summary.md`

## Strategy parity notes

- Long-only divergence extraction.
- Pivot low confirmation is delayed by `pivot_len` bars (non-repaint behavior).
- Memory of last pivot (`price/osc/bar`) is updated on every confirmed pivot low.
- Raw mode entries occur on the signal bar close.
- Confirm mode supports BOS trigger with wait/expiry and entry on trigger bar close.
- DMI/ADX uses Wilder formulas (`rma`) and rolling sums use `sma(x,len)*len`.
- Session gate defaults match Pine baseline:
  - `enabled=true`, `tz="Etc/GMT-3"`, NY on, London/Tokyo/Sydney off.
  - Raw divergence checks session at pivot bar (`time[pivotLen]`), BOS confirm checks session at current trigger bar (`time`).
- Events include pivot-time and entry-time research features (daily regime, volume behavior, CVD raw + normalized).
- Prefer normalized CVD gating (`enable_cvd_z_gate`) across symbols; legacy absolute CVD gate is still supported.

## Tests

Run:

```bash
pytest -q
```

Included parity tests:

- Pivot confirmation timing (`tests/test_pivot_confirmation.py`)
- Entry on signal bar close (`tests/test_entry_timing.py`)
- TP/SL same-bar tie-break + MFE/MAE (`tests/test_forward_tie_break.py`)

## TradingView reconciliation helper

`dfd05.reconcile.reconcile_with_tradingview_csv(...)` compares:

- entry timestamps
- entry prices
- trade count

against a TradingView export CSV.
