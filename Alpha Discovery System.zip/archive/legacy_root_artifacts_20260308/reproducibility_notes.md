# Reproducibility Notes

## Files Used
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\summary.md`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\index.html`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\overall.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\per_symbol_year.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\best_selection.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\barrier_results.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\claim_verification.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\config_audit.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\data\reports\dfd05_report_ny_london_20260306T193320Z\run_logs.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\expectancy_by_year.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\expectancy_by_config.csv`
- `C:\Users\USER\Projects\Alpha Discovery System\expectancy_by_year_recomputed.csv`

## Extraction Inventory
- Extracted ZIPs: `Alpha Discovery System.zip`, `dfd05_report_handoff_20260306.zip`, `handoff_artifacts.zip`, `dfd05_submission_outputs_20260305_20260306.zip`, `engineer_payload_v3.zip`, `reports.zip` into `audit_extract/`.
- No nested ZIPs were found inside these extracted artifacts.

## Assumptions
- 24h signal metrics are computed from `forward_path` parquet using non-truncated rows (`is_truncated_24h == 0`).
- Directional label uses `up_24h` exactly as stored in forward outputs.
- Excursion R normalization uses `mfe_atr_24h` and `mae_atr_24h` (configs use `sl_atr_mult = 1.0`).
- Year 2026 is treated as partial.

## Fallback Logic for R Normalization
- Preferred: ATR-normalized columns (`mfe_atr_24h`, `mae_atr_24h`).
- Fallback (not needed in this run): raw return units (`mfe_24h`, `mae_24h`) if ATR-normalized fields are missing.

## Missing Data / Conflicts
- Requested docs `DFDS_Strategy_Validation_Report.docx` and `Divergence_Alpha_Discovery_Engineering_Report.md` were not present.
- Barrier yearly metrics were recomputed from raw bars/events and written to `expectancy_by_year_recomputed.csv`.
- Recomputed barrier yearly metrics match `expectancy_by_year.csv` and `barrier_results.csv` exactly (differences only at floating-point epsilon).

## Why Earlier Validation Passed While Execution Fails
- Prior claim verification (`claim_verification.csv`) checks directional replication (`n_valid`, `up_rate`) for a single slice.
- It does not test barrier expectancy, so a PASS there does not imply trade profitability.
