# Model 16 Quantitative Validation Memo

## Executive Verdict
Model 16 has directional bias in multiple slices, but the current 1:3 execution model is not profitable or robust.

## Methodology Audit
- Primary files audited: `run_logs.csv`, `overall.csv`, `per_symbol_year.csv`, `best_selection.csv`, `barrier_results.csv`, `claim_verification.csv`, `config_audit.csv`, `summary.md`, `index.html` under `data/reports/dfd05_report_ny_london_20260306T193320Z`.
- Raw event-level recomputation source: `forward_path` parquet files referenced by `run_logs.csv` (30 config/timeframe/session slices).
- 1:3 barrier yearly outcomes were recomputed directly from raw bars/events (`compute_forward_for_events` in barrier mode) for selected executed slices and saved to `expectancy_by_year_recomputed.csv`.
- Recomputed yearly barrier totals match `expectancy_by_year.csv` and `barrier_results.csv` exactly (floating-point tolerance only).
- Missing requested docs: `DFDS_Strategy_Validation_Report.docx` and `Divergence_Alpha_Discovery_Engineering_Report.md` are not present in extracted artifacts.
- Methodological mistake in prior validation: `claim_verification.csv` validates only `n_valid` and `up_rate` for a slice; it does not validate barrier win-rate/expectancy. This conflates signal-direction checks with trade-profitability confirmation when read as a full validation pass.

## 24h Signal Quality (Signal Edge)
- m15 signal slices with `up_rate_24h > 50%`: 10/10.
- m15 signal slices with `mean_return_24h > 0`: 8/10.
- m15 `Edge_Ratio` median: 0.965 (threshold for edge > 1.0).
- Baseline m15 session_on: up_rate=53.19%, mean_ret=2.10 bps, Edge_Ratio=0.970.
- Prod m15 session_on: up_rate=50.43%, mean_ret=-2.27 bps, Edge_Ratio=0.963.

## 24h Excursion Asymmetry
- m15 average `avg_MFE_R`: 10 slices, median=5.325.
- m15 average `avg_MAE_R`: median=-5.607.
- m15 Edge_Ratio range: 0.911 to 1.010.
- Interpretation: favorable excursion does not consistently dominate adverse excursion; asymmetry is weak.

## Year-by-Year Robustness
- Years evaluated: 2022, 2023, 2024, 2025, 2026 (2026 is partial).
- m15 yearly results are regime-dependent; every m15 config has at least one negative 24h mean-return year.
- 2025 is a notable weak year for several m15 slices (including prod session_on).
- No selected m15 slice shows consistently positive barrier expectancy across all years.

Top configs by count of positive mean-return years (m15 only):

| config | years_with_positive_mean | years_total | worst_year_mean_bps | worst_year_barrier_R |
| --- | --- | --- | --- | --- |
| baseline|m15|session_off | 4 | 5 | -6.304085 | -0.401760 |
| bos_only|m15|session_off | 4 | 5 | -3.763417 | -0.293233 |
| gate_only|m15|session_on | 4 | 5 | -23.894031 | -0.304348 |
| baseline|m15|session_on | 3 | 5 | -5.066081 | -0.197133 |
| bos_plus_vol|m15|session_off | 3 | 5 | -6.524615 | -0.294118 |
| bos_only|m15|session_on | 3 | 5 | -11.182005 | -0.536232 |

## Barrier 1:3 Execution Audit
- Selected m15 barrier slices with `avg_R > 0`: 0/10.
- Baseline m15 session_on barrier: win_rate_1to3=23.75%, avg_R=-0.048902.
- Prod m15 session_on barrier: win_rate_1to3=17.26%, avg_R=-0.154867.
- Barrier and directional metrics are not equivalent; barrier profitability fails in the currently selected m15 execution setup.

## Final Classification
Category 2: DIRECTIONAL EDGE ONLY.

Rationale:
- Directional up-rate and 24h mean return are positive in many slices.
- Excursion asymmetry is weak (Edge_Ratio often near or below 1.0).
- Barrier expectancy is not validated for current 1:3 execution.
