# Corrected Summary

- Did the system truly have positive expectancy?
  - Not on a robust basis. Only 1/17 selected config-horizons is marginally positive (+0.0039R), 1 is exactly break-even, and 15 are negative.
- Which slice worked best?
  - `baseline|h1|session_off` at 72h is best on aggregate (`expectancy_R=0.003861`, `PF=1.0052`), but it is negative in 2022 and 2023.
- Is it robust enough for deployment?
  - No. No selected configuration is positive in every year across 2022-2025 (2026 is partial).

Final classification: CASE B (directional signal often positive, 1:3 barrier execution not validated).
