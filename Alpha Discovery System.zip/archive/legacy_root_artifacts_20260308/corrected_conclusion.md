# Corrected Conclusion

- **Does Model 16 have edge?** Yes, directional edge appears in multiple slices, but it is weak and regime-dependent.
- **Signal edge only, or full strategy edge?** Signal edge only.
- **Is current 1:3 execution valid?** No. The selected m15 barrier outcomes are non-positive on expectancy.
- **Is the model worth keeping as a signal engine?** Potentially yes, but only as a candidate signal source pending execution redesign and stricter robustness controls.

Model 16 shows DIRECTIONAL EDGE, but the current execution model is not validated.
