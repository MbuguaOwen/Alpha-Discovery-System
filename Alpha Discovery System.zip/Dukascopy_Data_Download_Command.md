# 1) Download/restore more Dukascopy pairs (m1 + derived m15/m30/h1/h4)
python -m scripts.restore_dukascopy_bars `
  --symbols XAUUSD XAGUSD EURUSD GBPUSD USDJPY AUDUSD NZDUSD USDCAD USDCHF EURJPY GBPJPY EURGBP `
  --start-date 2022-01-01 --end-date 2026-01-01 --warmup-days 45 `
  --output-root data/derived/dukascopy `
  --build-timeframes m1 m15 m30 h1 h4 `
  --max-concurrency 20 --retries 3 --timeout-sec 20 `
  --fill-unexpected-gaps --max-fill-minutes 3

# 2) Retry only failed download days from manifest
python -m scripts.restore_dukascopy_bars `
  --symbols XAUUSD XAGUSD EURUSD GBPUSD USDJPY AUDUSD NZDUSD USDCAD USDCHF EURJPY GBPJPY EURGBP `
  --start-date 2022-01-01 --end-date 2026-01-01 --warmup-days 45 `
  --output-root data/derived/dukascopy `
  --build-timeframes m1 m15 m30 h1 h4 `
  --retry-manifest data/derived/dukascopy/restore_logs/download_manifest.csv `
  --max-concurrency 16 --retries 3 --timeout-sec 10 `
  --fill-unexpected-gaps --max-fill-minutes 3

# 3) Run forward-sign study on those pairs (all sessions, m15)
python -m scripts.pine16_forward_sign_study `
  --config configs/pine16_forwardsign_m30_fxmajors_metals_all_sessions.yaml `
  --truth-mode verified_python_parity `
  --timeframe m15 `
  --output-dir outputs/reports_m15_fxmajors_metals_all_sessions `
  --master-path data/derived/pine16_exact/forward_sign_24h_72h_master_m15_fxmajors_metals_all_sessions.parquet `
  --export-html

# 4) Rank top London+NY symbols at 24h (n>=30)
Import-Csv outputs/reports_m15_fxmajors_metals_all_sessions/pine16_forward_sign_24h_72h_by_symbol_session.csv |
Where-Object { $_.analysis_session_scope -eq 'london_or_newyork' -and [int]$_.horizon_h -eq 24 -and [int]$_.n_signals -ge 30 } |
Sort-Object { [double]$_.win_rate } -Descending |
Select-Object -First 10 symbol,n_signals,win_rate,mean_forward_return_pct,median_forward_return_pct
